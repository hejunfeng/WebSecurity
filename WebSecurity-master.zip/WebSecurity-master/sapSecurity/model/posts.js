const conn = require('./connection');
var Promise = require('bluebird');

module.exports.index =  function (req,res) {
	var promisPosts = Promise.using(conn.getConnection(), function(connection) {
		return connection.query('select post.*,count(comment.id) as commentCount from post left join comment on post.id = comment.postId group by post.id limit 10');
	});
	var promisComments = Promise.using(conn.getConnection(), function(connection) {
		return connection.query('select comment.*,post.id as postId,post.title as postTitle,user.username as username from comment left join post on comment.postId = post.id left join user on comment.userId = user.id order by comment.id desc limit 10');
	});

	Promise.all([promisComments,promisPosts]).then(function (result) {
		const posts = result[1];
		const comments = result[0];
		res.render('index',{posts,comments,from:req.query.from || ''});
	});

};