var config = require('config-lite')(__dirname);

var mysql = require('promise-mysql');
 
var pool = mysql.createPool(config.mysql);
 
function getConnection() {
	return pool.getConnection().disposer(function(connection) {
		pool.releaseConnection(connection);
	});
}
 
module.exports.getConnection = getConnection;