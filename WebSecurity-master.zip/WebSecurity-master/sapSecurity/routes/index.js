var express = require('express');
var router = express.Router();
const postsModel = require('../model/posts');

/* GET home page. */
router.all('/*',  function(req ,res , next){
	console.log('Add Response Header');
	res.set('X-XSS-Protection',0);
	res.set('Access-Control-Allow-Origin','*');
	// res.set('Content-Security-Policy', 'default-src \'self\';img-src * ');
	next();
	
});

router.get('/', function (req,res) {
	postsModel.index(req,res);
});


module.exports = router;
