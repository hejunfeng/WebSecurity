module.exports = {
	mysql : {
		host: 'localhost',
		password: 'root',
		database: 'safety',
		user: 'root',
		port: '3306'
	}
};